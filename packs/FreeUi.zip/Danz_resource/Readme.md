Author: DANZGAME x Fless
Name: FreedomUi (Car)
Version: v1.1.0
File Size: 1.47 MB

FreedomUI is a name derived from the word Freedom, which means developing ideas in a field.

Features In FreedomUi:
1. Change The Main Menu View
2. Change Creator Layer View
3. Shader Menu In Main Menu
4. Animated Background

Must Download Mods:
1. Texture Loader
2. Menu Shader
3. Happy Texture
4. Animate This Sprite

Changelog:
v1.0.0 : 2/5/2025
Ui released and uploaded to Texture workshop 

v1.1.0 :
Fixed bug in layer creator on pc
Fixed bug in main menu on pc
Adding animated background

Special Thanks To BoomyBoomer123 For Helping Me Find The Error In The Ui